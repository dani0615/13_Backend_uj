﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace KutyakApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Kutya_GazdaController : ControllerBase
    {
        //[HttpGet("GetKutya_Gazda")]
        //public IActionResult GetKutya_Gazda() 
        //{

        //}

    }
}
