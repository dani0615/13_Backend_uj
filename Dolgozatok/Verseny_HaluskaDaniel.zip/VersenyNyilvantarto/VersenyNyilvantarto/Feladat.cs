﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VersenyNyilvantarto
{
    public class Feladat
    {
       public int Id;
       public string Szoveg;
        public string Valasz1;
        public string Valasz2;
        public string Valasz3;
        public string Valasz4;

        
        public int HelyesValasz;
  
        public int Pont;

        
            } }
    

